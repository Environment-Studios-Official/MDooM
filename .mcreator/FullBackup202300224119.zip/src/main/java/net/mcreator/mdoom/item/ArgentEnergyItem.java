
package net.mcreator.mdoom.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class ArgentEnergyItem extends Item {
	public ArgentEnergyItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON));
	}
}
